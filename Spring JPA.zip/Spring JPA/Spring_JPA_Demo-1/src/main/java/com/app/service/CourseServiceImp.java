package com.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.entity.Course;
import com.app.entity.CourseMaterial;
import com.app.exception.courseException.CourseAlreadyExistException;
import com.app.exception.courseException.CourseNotFoundException;
import com.app.repository.CourseMaterialRepository;
import com.app.repository.CourseRepository;

@Service
public class CourseServiceImp implements CourseService {

	@Autowired
	private CourseRepository courseRepository;

	@Autowired
	private CourseMaterialRepository courseMaterialRepository;
	
	@Override
	public List<Course> getAllCourses() {
		List<Course> courses = courseRepository.findAll();
		if (courses == null)
			throw new CourseNotFoundException("All Courses not found");
		return courses;
	}

	@Override
	public Course getCourseById(long id) {
		Optional<Course> course = courseRepository.findById(id);
		if (course.isEmpty())
			throw new CourseNotFoundException("Course with id: " + id + " not found!!");
		return course.get();
	}

	@Override
	public Course createCourse(Course course) {
		if (course == null) {
			throw new CourseNotFoundException("Please Enter the course Details!!");
		}
		Course existingCourse = courseRepository.findByCourseName(course.getCourseName());
		if (existingCourse != null)
			throw new CourseAlreadyExistException("Course Already Exist!!");

		String existingCourseMaterialName = course.getCourseMaterial().getCourseMaterialName();
		CourseMaterial existingCourseMaterial = courseMaterialRepository.findByCourseMaterialName(existingCourseMaterialName);
		if(existingCourseMaterial != null)
			course.setCourseMaterial(existingCourseMaterial);
		
		return courseRepository.save(course);
	}

	@Override
	public void deleteCourse(String id) {
		Optional<Course> course = courseRepository.findById(Long.parseLong(id));
		if (course.isEmpty())
			throw new CourseNotFoundException("Course With id: " + id + " not found!!!");
		courseRepository.deleteById(Long.parseLong(id));
	}
}
