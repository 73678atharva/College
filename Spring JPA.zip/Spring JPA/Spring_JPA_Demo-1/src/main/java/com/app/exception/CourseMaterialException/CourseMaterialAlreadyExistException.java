package com.app.exception.CourseMaterialException;


public class CourseMaterialAlreadyExistException{
	
}
