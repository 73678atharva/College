package com.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.app.entity.CourseMaterial;
import com.app.service.CourseMaterialService;

@RestController
public class CourseMaterialController {

	@Autowired
	private CourseMaterialService courseMaterialService;
	
	@PostMapping("/create/courseMaterial")
	public ResponseEntity<CourseMaterial> createNewCourseMaterial(@RequestBody CourseMaterial courseMaterial){
		CourseMaterial newCourseMaterial = courseMaterialService.createCourseMaterial(courseMaterial);
		return ResponseEntity.status(HttpStatus.CREATED).body(newCourseMaterial);
	}
	
	@GetMapping("/courseMaterial/{id}")
	public ResponseEntity<CourseMaterial> getSingleCourseMaterial(@PathVariable String id){
		CourseMaterial existingCourseMaterial = courseMaterialService.getCourseById(Long.parseLong(id));
		return ResponseEntity.status(HttpStatus.FOUND).body(existingCourseMaterial); 
	}
}
