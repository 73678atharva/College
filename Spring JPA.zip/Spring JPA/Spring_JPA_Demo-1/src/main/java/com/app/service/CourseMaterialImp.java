package com.app.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.app.entity.CourseMaterial;
import com.app.exception.CustomException;
import com.app.exception.CourseMaterialException.CourseMaterialNotFoundException;
import com.app.repository.CourseMaterialRepository;

@Service
public class CourseMaterialImp implements CourseMaterialService{

	@Autowired
	private CourseMaterialRepository courseMaterialRepository;
	

	@Override
	public CourseMaterial createCourseMaterial(CourseMaterial courseMaterial) {
		if(courseMaterialRepository.findByCourseMaterialName(courseMaterial.getCourseMaterialName()) != null)
			throw new CustomException("Course Material ALready Exisit!!", HttpStatus.CONFLICT);
		return courseMaterialRepository.save(courseMaterial);
		}


	@Override
	public CourseMaterial getCourseById(long id) {
		Optional<CourseMaterial> existingCourseMaterial = courseMaterialRepository.findById(id);
		if(existingCourseMaterial.isEmpty())
			throw new CourseMaterialNotFoundException("Course Material with id: "+ id + " not Found!!!");
		System.out.println(existingCourseMaterial);
		return existingCourseMaterial.get();
	}
	
	
}
