package com.app.service;

import java.util.List;

import com.app.entity.Course;

public interface CourseService {

	public List<Course> getAllCourses();

	public Course getCourseById(long id);
	
	public Course createCourse(Course course);
	
	public void deleteCourse(String id);
}
