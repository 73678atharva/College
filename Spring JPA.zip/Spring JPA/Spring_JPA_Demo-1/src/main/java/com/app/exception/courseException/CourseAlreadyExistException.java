package com.app.exception.courseException;

import org.springframework.http.HttpStatus;

import com.app.exception.CustomException;

public class CourseAlreadyExistException extends CustomException{

	private static final long serialVersionUID = 1L;

	public CourseAlreadyExistException(String message) {
		super(message, HttpStatus.CONFLICT);

	}
	
}
