package com.app.service;

import com.app.entity.Student;
public interface StudentService {
	
	public Student createStudent(Student student);
	
	public Student findById(long id);
}
