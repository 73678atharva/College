package com.app.exception.studentException;

import org.springframework.http.HttpStatus;

import com.app.exception.CustomException;

public class StudentNotFoundException extends CustomException{
	
	private static final long serialVersionUID = 1L;

	public StudentNotFoundException(String message) {
		super(message,HttpStatus.NOT_FOUND);
	}
}
