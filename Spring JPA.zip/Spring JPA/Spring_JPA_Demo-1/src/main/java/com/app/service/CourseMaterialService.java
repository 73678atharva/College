package com.app.service;

import com.app.entity.CourseMaterial;

public interface CourseMaterialService {

	public CourseMaterial createCourseMaterial(CourseMaterial courseMaterial);
	
	public CourseMaterial getCourseById(long id);
}
