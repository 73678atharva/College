package com.app.exception.courseException;

import org.springframework.http.HttpStatus;

import com.app.exception.CustomException;

public class CourseNotFoundException extends CustomException{

	private static final long serialVersionUID = 1L;

	public CourseNotFoundException(String message) {
		super(message, HttpStatus.NOT_FOUND);
	}	
}
