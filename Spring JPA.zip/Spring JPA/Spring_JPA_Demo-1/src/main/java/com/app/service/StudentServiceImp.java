package com.app.service;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.app.entity.Course;
import com.app.entity.Student;
import com.app.exception.studentException.StudentAlreadyExistException;
import com.app.exception.studentException.StudentNotFoundException;
import com.app.repository.CourseRepository;
import com.app.repository.StudentRepository;

@Service
public class StudentServiceImp implements StudentService{

	@Autowired
	private StudentRepository studentRepository;
	
	@Autowired
	private CourseRepository courseRepository;
	
	@Override
	public Student createStudent(Student student){
		Student existingStudent = studentRepository.findByFirstName(student.getFirstName());
		if(existingStudent != null){
			throw new StudentAlreadyExistException("Student with name "+ student.getFirstName()+ " already exists");
		}
		List<Course> studentCourse = student.getCourses();
		List<Course> courseToBeAdded = new ArrayList<>();
		for (Course course : studentCourse) {
			Course existingCourse = courseRepository.findByCourseName(course.getCourseName());
			if(existingCourse != null)
				courseToBeAdded.add(existingCourse);
		}
		if(!courseToBeAdded.isEmpty())
			student.setCourses(courseToBeAdded);
		
		return studentRepository.save(student);	 
	}
	
	@Override
	public Student findById(long id) {
		Optional<Student> student = studentRepository.findById(id);
		if(student.isEmpty())
			throw new StudentNotFoundException("Student with Id: "+ id + " not found");
		return student.get();
	}
	
}
