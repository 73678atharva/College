package com.app.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.app.entity.User;
import com.app.entity.UserDTO;
import com.app.exception.CustomException;
import com.app.mapper.UserMapper;
import com.app.repository.UserRepository;

@Service
public class UserServiceImp implements UserService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;

	@Override
	public UserDTO createUser(User user) {
		Optional<User> existingUser = userRepository.findById(user.getId());
		if (existingUser.isPresent())
			throw new CustomException("User Already Exists!!!", HttpStatus.CONFLICT);
		user.setPassword(bCryptPasswordEncoder.encode(user.getPassword()));
		return UserMapper.convertUserToUserDTO(userRepository.save(user));
	}

	@Override
	public UserDTO loginUser(User user) {
		User existingUser = userRepository.findByUsername(user.getUsername());
		if(existingUser == null)
			throw new CustomException("User name is incorrect!!", HttpStatus.NOT_ACCEPTABLE);
		return UserMapper.convertUserToUserDTO(existingUser);
	}
}
