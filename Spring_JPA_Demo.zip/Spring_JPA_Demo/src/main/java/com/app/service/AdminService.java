package com.app.service;

import com.app.entity.Admin;
import com.app.entity.AdminDTO;
import com.app.entity.User;

public interface AdminService {

	public String registerAdmin(Admin admin);
	
	public String loginAdmin(User user);

	public AdminDTO getCurrentAdminDetials(String adminUserName);

	public Admin updateCurrentAdminDetails(Admin admin);
}
