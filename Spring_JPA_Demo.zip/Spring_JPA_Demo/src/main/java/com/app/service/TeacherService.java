package com.app.service;

import com.app.entity.Teacher;
import com.app.entity.TeacherDTO;

public interface TeacherService {

	public String createTeacher(Teacher teacher);
	
	public TeacherDTO getSingleTeacher(String id);
	
	public String deleteTeacher(String id);
	
	public TeacherDTO updateTeacher(Teacher teacher);
}
