package com.app.service;

import com.app.entity.Student;
import com.app.entity.StudentDTO;

public interface StudentService {
	
	public String createStudent(Student student);
	
	public StudentDTO findById(long id);

	public String deleteStudent();
}
