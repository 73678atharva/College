package com.app.service;

import com.app.entity.Student;
import com.app.entity.StudentDTO;

public interface StudentService {
	
	public String createStudent(Student student);
	
	public StudentDTO findCurrentStudentDetails(String userName);
	
	public StudentDTO updateCurrentStudentDetails(Student student);

	public String deleteStudent();
}
